import turtle

wn = turtle.Screen()
wn.title("Черепашка рисует узоры")
wn.bgcolor("white")

t = turtle.Turtle()
t.shape("turtle")
t.speed(3)

def draw_star():
    t.penup()
    t.goto(-200, 0)
    t.pendown()
    t.color("orange")
    for _ in range(5):
        t.forward(100)
        t.right(144)

def draw_web():
    t.penup()
    t.goto(0, 0)
    t.pendown()
    t.color("grey")
    for _ in range(12):
        t.forward(100)
        t.backward(100)
        t.right(30)

def draw_flower():
    t.penup()
    t.goto(0, -200)
    t.pendown()
    t.color("red")
    for _ in range(36):
        t.circle(50, 60)
        t.left(120)
        t.circle(50, 60)
        t.left(10)

def draw_squares():
    t.penup()
    t.goto(-200, 200)
    t.pendown()
    for i in range(5, 60, 2):
        for _ in range(4):
            t.forward(i)
            t.right(90)
        t.penup()
        t.backward(10)
        t.right(90)
        t.forward(10)
        t.left(90)
        t.pendown()

def draw_square_spiral():
    t.penup()
    t.goto(200, 200)
    t.pendown()
    t.color("magenta")
    for i in range(20):
        for _ in range(4):
            t.forward(i * 10)
            t.right(90)
        t.right(20)

def draw_labyrinth():
    t.penup()
    t.goto(-200, -200)
    t.pendown()
    t.color("lime")
    for i in range(20):
        t.forward(i * 20)
        t.right(90)

def draw_wave():
    t.penup()
    t.goto(-300, 0)
    t.pendown()
    t.color("cyan")
    for _ in range(12):
        t.circle(40, 90)
        t.circle(-40, 90)

def draw_spiral():
    t.penup()
    t.goto(100, 0)
    t.pendown()
    for i in range(20):
        t.circle(10 * i, 180)

def on_q_press():
    draw_squares()

def on_f_press():
    draw_web()

def on_e_press():
    draw_wave()

def on_c_press():
    draw_square_spiral()

def on_s_press():
    draw_spiral()

def on_a_press():
    draw_star()

def on_d_press():
    draw_flower()

def on_w_press():
    draw_labyrinth()


wn.onkey(on_a_press, "a")
wn.onkey(on_d_press, "d")
wn.onkey(on_s_press, "s")
wn.onkey(on_q_press, "q")
wn.onkey(on_e_press, "e")
wn.onkey(on_c_press, "c")
wn.onkey(on_w_press, "w")
wn.onkey(on_f_press, "f")

wn.listen()
turtle.done()
